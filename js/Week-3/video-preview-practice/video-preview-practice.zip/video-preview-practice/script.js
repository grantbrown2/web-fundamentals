console.log("page loaded...");
function playVid(vid) {
    console.log(vid);
    vid.play();
}

function pauseVid(vid) {
    console.log(vid);
    vid.pause();
}