function logout(element) {
    element.innerText = "Logout";
}
function adddef(element) {
    element.remove();
}
function giveAlert(){
    alert("Ninja was liked");
}